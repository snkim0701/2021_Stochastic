clear all; clc
dt = 0.05;      % sampling time
t = 0:dt:20;
Nsamples = length(t);

% for analysis
Xsaved = zeros(Nsamples,3);
Zsaved = zeros(Nsamples,1);
EKFdistance = zeros(Nsamples,1);


for k = 1:  Nsamples
    
    r = GetRadar(dt);                        % measured distance
    
    [pos, vel, alt] = RadarEKF(r,dt);       % Estimation using EKF
%     alt
    EKFdistance(k) = sqrt(pos.^2 + alt.^2);
    Xsaved(k,:) = [pos vel alt];
    Zsaved(k) = r;
end

PosSaved = Xsaved(:,1);      % horizontal distance
VelSaved = Xsaved(:,2);       % velocity 
Altsaved = Xsaved(:,3);        % altitude

t = 0:dt:Nsamples*dt-dt;
figure(1)
plot(t, PosSaved); grid on

figure(2)
plot(t, VelSaved); grid on

figure(3)
plot(t, Altsaved); grid on
% plot(Altsaved)

