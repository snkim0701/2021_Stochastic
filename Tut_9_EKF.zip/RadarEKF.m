function [pos, vel, alt] = RadarEKF(z,dt)
    persistent Phi W V
    persistent xEst P
    persistent firstRun 
if isempty(firstRun)
    Phi = eye(3) + dt*[0 1 0; 0 0 0; 0 0 0];
    W =[0 0 0; 0 0.001 0; 0 0 0.001];
    V = 100;
    xEst = [0 90 1100]';  % initial estimation 
    P = 10*eye(3);         % initial estimation 
    
    firstRun = 1;
end

% Jacobian for linearization 
H  = Hjacob(xEst);    %non-linear system matrix 

% prediction
xPre = Phi*xEst;
M = Phi*P*Phi' + W;

% Kalman gain
K = M*H'*inv(H*M*H' + V);

xEst = xPre + K*(z - hx(xPre));
P = M - K*H*M;

pos =xEst(1);
vel=xEst(2);
alt =xEst(3);
end

function zp = hx(xhat)     % measurement non-linear transform
    x1 = xhat(1);
    x3 = xhat(3);
    
    zp = sqrt(x1^2 + x3^2);
end

function H = Hjacob(xPre)
    H = zeros(1,3);
    
    x1 = xPre(1);
    x3 = xPre(3);
    
    H(1) = x1 / sqrt(x1^2 + x3^2);
    H(2) = 0;
    H(3) = x3 / sqrt(x1^2 + x3^2);
end