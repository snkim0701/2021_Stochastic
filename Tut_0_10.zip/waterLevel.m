function z = waterLevel(a,dt)
%
persistent level 

if isempty(level)
    level =100;   % initial water level
end

%
level = level + a*dt;

v = 0 + 10*randn(1,1);    %  zero mean and variance = 1 

z = level + v;                 %  measurement