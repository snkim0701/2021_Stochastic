clear all;clc
dt = 0.1;
t  = 0:dt:20;
a = 10;
Nsamples = length(t);
Xsaved = zeros(Nsamples, 3);
Zsaved = zeros(Nsamples, 1);

for k=1:Nsamples
  z = waterLevel(a, dt);
  [eLevel, eFlow] = waterKalman(z,dt);  
  Xsaved(k,1) =eLevel;
  Xsaved(k,2) =eFlow;
  Zsaved(k) = z;
end
figure(1)
plot(t, Xsaved(:,1)); hold on; grid on
plot(t, Zsaved, 'r') 
hold off
% xlabel('Time [sec]')
% ylabel('Voltage [V]')
% legend('Kalman Filter', 'Measurements')
% 
figure(2)
plot(t, Xsaved(:,2)); grid on
% xlabel('Time [sec]')
% ylabel('P')
% 
% figure
% plot(t, Xsaved(:,3), 'o-')
% xlabel('Time [sec]')
% ylabel('K')
