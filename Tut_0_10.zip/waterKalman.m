function [eLevel, eFlow]= waterKalman(z,dt)
% persistent vriables : only in function variables
% for initialization it is good
% 
persistent Phi H G V            
persistent xEst P
persistent firstRun


if isempty(firstRun)     % at first firstREun = 0                              
  Phi = [1 dt; 0 1];
  H = [1 0];  
  G = [0 0;0 0];
  V =1;
  
  xEst = [10 5]';                  % initial guess
  P =  [ 1 0; 0 1];                  % initial guess
  firstRun = 1;  
end  


xPre = Phi*xEst;
M = Phi*P*Phi' + G;
K = M*H'*inv(H*M*H' + V);
xEst = xPre + K*(z - H*xPre);
P = M - K*H*M;
eLevel = xEst(1);
eFlow  = xEst(2);
% Cov = P;