
%% estimate an integtral using Monte Carlo
clear all; clc
N = 2000;
pts = rand(N,1);
plot(pts,'+')
% f = exp(sin(pts));
f=pts.^2;
sum = 0;
for i = 1:N
    sum = sum + f(i);
end
sum/N



%% estimate the pi  using Monte Carlo
clear all; clc
N = 2000;
pts = -1+ 2*rand(N,2);
scatter(pts(:,1), pts(:,2))
cts =0;
for i = 1:N
    if pts(i,1).^2 + pts(i,2).^2 <=1 
        cts = cts+1;
    end
end 
% 4:(pi)R^2 = N : cts
cts*4/N