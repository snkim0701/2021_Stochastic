function [Xi W] = SigmaPoints(xm, P, lambda)
%
%
n  = numel(xm);
Xi = zeros(n, 2*n+1);              % sigma points = col of Xi
W  = zeros(n, 1);                   % weighting factor

Xi(:, 1) = xm;                        % the first sigma point in 4.2 , eq(a)  
W(1)     = lambda / (n + lambda);  % the first weighting factor

U = chol((n+lambda)*P);             % U*U' = (n+kappa)*P

for k=1:n
  Xi(:, k+1) = xm + U(k, :)';      % in 4.2 eq(b) 
  W(k+1)     = 1 / (2*(n+lambda));
end

for k=1:n
  Xi(:, n+k+1) = xm - U(k, :)';    % in 4.2 eq(c)
  W(n+k+1)      = 1 / (2*(n+lambda));
end